import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Post } from "./Post";
import { Doc } from "../../convex/_generated/dataModel";

type PostWithDetails = Doc<"posts"> & {
  user: Doc<"users">;
  likesCount: number;
  commentsCount: number;
  isLiked: boolean;
  imageUrl: string | null;
};

export function Feed() {
  const posts = useQuery(api.posts.feed) as PostWithDetails[] | undefined;

  if (!posts) {
    return (
      <div className="flex justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {posts.map((post) => (
        <Post key={post._id} post={post} />
      ))}
    </div>
  );
}
