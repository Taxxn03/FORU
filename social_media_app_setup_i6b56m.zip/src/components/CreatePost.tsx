import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

export function CreatePost() {
  const generateUploadUrl = useMutation(api.posts.generateUploadUrl);
  const createPost = useMutation(api.posts.createPost);
  const [caption, setCaption] = useState("");
  const [image, setImage] = useState<File | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!image || !caption.trim()) return;

    const postUrl = await generateUploadUrl();
    const result = await fetch(postUrl, {
      method: "POST",
      headers: { "Content-Type": image.type },
      body: image,
    });
    const { storageId } = await result.json();
    await createPost({ imageId: storageId, caption });
    
    setCaption("");
    setImage(null);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-4 rounded-lg shadow">
      <input
        type="file"
        accept="image/*"
        onChange={(e) => setImage(e.target.files?.[0] ?? null)}
        className="w-full"
      />
      <textarea
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        placeholder="Write a caption..."
        className="w-full p-2 border rounded-lg"
        rows={3}
      />
      <button
        type="submit"
        disabled={!image || !caption.trim()}
        className="w-full py-2 bg-indigo-600 text-white rounded-lg disabled:opacity-50"
      >
        Share Post
      </button>
    </form>
  );
}
