import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Feed } from "./components/Feed";
import { CreatePost } from "./components/CreatePost";
import { Toaster } from "./components/ui/toaster";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-2xl font-bold text-indigo-600">FORU</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-4">
        <div className="max-w-2xl mx-auto">
          <Authenticated>
            <div className="space-y-8">
              <CreatePost />
              <Feed />
            </div>
          </Authenticated>
          <Unauthenticated>
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-indigo-600">Welcome to FORU</h1>
              <p className="text-gray-600">Sign in to start sharing moments</p>
              <SignInForm />
            </div>
          </Unauthenticated>
        </div>
      </main>
      <Toaster />
    </div>
  );
}
