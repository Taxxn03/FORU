import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import { Heart, MessageCircle } from "lucide-react";
import { Doc, Id } from "../../convex/_generated/dataModel";

type PostProps = {
  post: Doc<"posts"> & {
    user: Doc<"users">;
    likesCount: number;
    commentsCount: number;
    isLiked: boolean;
    imageUrl: string | null;
  };
};

export function Post({ post }: PostProps) {
  const toggleLike = useMutation(api.social.toggleLike);
  const addComment = useMutation(api.social.addComment);
  const [comment, setComment] = useState("");

  return (
    <div className="bg-white rounded-lg shadow">
      {post.imageUrl && (
        <img
          src={post.imageUrl}
          alt={post.caption}
          className="w-full h-96 object-cover rounded-t-lg"
        />
      )}
      <div className="p-4 space-y-4">
        <div className="flex items-center gap-2">
          {post.user.image && (
            <img
              src={post.user.image}
              alt={post.user.name || "User"}
              className="w-8 h-8 rounded-full"
            />
          )}
          <span className="font-semibold">{post.user.name || "Anonymous"}</span>
        </div>
        <p>{post.caption}</p>
        <div className="flex items-center gap-4">
          <button
            onClick={() => toggleLike({ postId: post._id })}
            className={`flex items-center gap-1 ${
              post.isLiked ? "text-red-500" : "text-gray-500"
            }`}
          >
            <Heart className="w-6 h-6" fill={post.isLiked ? "currentColor" : "none"} />
            <span>{post.likesCount}</span>
          </button>
          <div className="flex items-center gap-1 text-gray-500">
            <MessageCircle className="w-6 h-6" />
            <span>{post.commentsCount}</span>
          </div>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!comment.trim()) return;
            addComment({ postId: post._id, content: comment });
            setComment("");
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Add a comment..."
            className="flex-1 px-3 py-2 border rounded-lg"
          />
          <button
            type="submit"
            disabled={!comment.trim()}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg disabled:opacity-50"
          >
            Post
          </button>
        </form>
      </div>
    </div>
  );
}
